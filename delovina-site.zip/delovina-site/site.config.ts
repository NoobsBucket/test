/**
 * Site-wide settings. Change these before you launch.
 */
export const SITE = {
  name: "Delovina",
  description:
    "Delovina designs and builds websites, mobile apps, games and full-stack software. Pick a service and get a price range and delivery time in seconds.",
  /** PLACEHOLDER: replace with your real contact email */
  email: "hello@example.com",
  nav: [
    { label: "Services", href: "#services", id: "services" },
    { label: "Process", href: "#process", id: "process" },
    { label: "Stack", href: "#stack", id: "stack" },
    { label: "Reviews", href: "#reviews", id: "reviews" },
    { label: "Contact", href: "#contact", id: "contact" },
  ],
} as const;
