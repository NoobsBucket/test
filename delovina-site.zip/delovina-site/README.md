# Delovina home page

A Next.js (App Router) home page that puts your four components together.

    npm install
    npm run dev        # http://localhost:3000

## Page order

1. Nav (sticky, highlights the section you are in, mobile menu)
2. Hero: `components/DelovinaHero.tsx`
3. Services printer: `components/ServicesPrinter.tsx`
4. Process (three steps)
5. Tech stack chalkboard: `components/DelovinaTechStack.tsx`
6. Corkboard reviews: `components/CorkboardTestimonials.tsx`
7. Contact and footer

## Fonts

- **Outfit**: the site font (nav, headings, buttons, hero, printer, review header). Loaded once in `app/layout.tsx`.
- **JetBrains Mono**: the TV in the hero (also in `app/layout.tsx`).
- **Newsreader**: only the passport card (country name, service name, seal).
- **Caveat Brush and Patrick Hand**: only inside the chalkboard and corkboard, where the handwriting fits the theme.

## Replace before you launch

| What | Where |
| --- | --- |
| Contact email (placeholder) | `site.config.ts` |
| Prices and delivery times (placeholders) | `SERVICES` in `components/ServicesPrinter.tsx` |
| Client reviews (placeholders) | `SAMPLE_TESTIMONIALS` in `components/CorkboardTestimonials.tsx` |
| Process copy | `STEPS` in `app/page.tsx` |
| Hero headlines | `SLIDES` in `components/DelovinaHero.tsx` |

## The chat link

The printer's "Chat about this" button opens `/chat?service=...`. `app/chat/page.tsx`
is a simple stand-in: it shows the chosen service and lets the visitor send the message by
email. Replace it with your real chat page when you have one. It receives the same query
parameters (`service`, `name`, `min`, `max`, `currency`, `delivery`, `message`).
