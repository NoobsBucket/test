import Link from "next/link";
import CorkboardTestimonials from "../components/CorkboardTestimonials";
import DelovinaHero from "../components/DelovinaHero";
import DelovinaTechStack from "../components/DelovinaTechStack";
import ServicesPrinter from "../components/ServicesPrinter";
import SiteFooter from "../components/SiteFooter";
import SiteNav from "../components/SiteNav";
import { SITE } from "../site.config";

/* PLACEHOLDER copy: edit to match how you really work. */
const STEPS = [
  {
    title: "Tell us what you need",
    text: "Pick a service above or describe your idea in a few lines. Rough is fine.",
  },
  {
    title: "Get a clear estimate",
    text: "We confirm the scope and share a price range and delivery time before any work starts.",
  },
  {
    title: "We build and ship",
    text: "Design, development and launch by one team, with regular updates along the way.",
  },
];

export default function HomePage() {
  return (
    <>
      <a className="skip" href="#main">
        Skip to content
      </a>
      <SiteNav />

      <main id="main">
        <h1 className="sr-only">{SITE.name}: custom software, websites, mobile apps and games</h1>

        <div id="top" className="hero-wrap">
          <DelovinaHero contactHref="#contact" servicesHref="#services" />
        </div>

        <section id="services" className="band pad-section" aria-label="Services">
          <ServicesPrinter
            chatHref="/chat"
            eyebrow="Services"
            title="Pick a service, get your estimate"
            subtitle="Press a key on the printer. Your service card prints with a price range and delivery time."
          />
        </section>

        <section id="process" className="process" aria-labelledby="process-title">
          <div className="container">
            <div className="section-head">
              <span className="eyebrow">Process</span>
              <h2 id="process-title">From idea to launch in three steps</h2>
              <p>No long onboarding. Start with a question and we take it from there.</p>
            </div>
            <ol className="steps">
              {STEPS.map((s, i) => (
                <li key={s.title} className="step">
                  <span className="step-no">{String(i + 1).padStart(2, "0")}</span>
                  <h3>{s.title}</h3>
                  <p>{s.text}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section id="stack" aria-label="Tech stack">
          <DelovinaTechStack />
        </section>

        <section id="reviews" className="band pad-section" aria-label="Client reviews">
          <CorkboardTestimonials ctaHref="#contact" />
        </section>

        <section id="contact" className="contact" aria-labelledby="contact-title">
          <div className="container contact-inner">
            <div>
              <span className="eyebrow">Contact</span>
              <h2 id="contact-title">Have something in mind? Let&apos;s build it.</h2>
            </div>
            <div className="contact-side">
              <p>Tell us what you are building. We will come back with questions, a price range and a delivery time.</p>
              <div className="contact-actions">
                <Link className="btn btn-light" href="/chat">
                  Chat about your project
                </Link>
                <a className="btn btn-outline-light" href={`mailto:${SITE.email}`}>
                  Email us
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
    </>
  );
}
