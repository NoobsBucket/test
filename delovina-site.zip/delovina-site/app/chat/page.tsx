"use client";

/**
 * Stand-in for your chat page. The service printer sends visitors here with the
 * selected service in the URL. This page shows the summary and lets them send
 * the message by email. Replace it with your real chat when you have one.
 */

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import SiteFooter from "../../components/SiteFooter";
import SiteNav from "../../components/SiteNav";
import { SITE } from "../../site.config";

const money = (n: number) => `$${n.toLocaleString("en-US")}`;

function ChatForm() {
  const params = useSearchParams();
  const name = params.get("name");
  const min = Number(params.get("min"));
  const max = Number(params.get("max"));
  const delivery = params.get("delivery");
  const hasPrice = Number.isFinite(min) && Number.isFinite(max) && max > 0;

  const [message, setMessage] = useState(params.get("message") ?? "");

  const subject = name ? `Project enquiry: ${name}` : "Project enquiry";
  const mailto = `mailto:${SITE.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(message)}`;

  return (
    <div className="chat-card">
      <h1>{name ? `Let's talk about your ${name.toLowerCase()}` : "Tell us about your project"}</h1>
      <p>Add a few details below, then send it. The more you share, the better our first answer will be.</p>

      {name && (
        <dl className="chat-sum">
          <div>
            <dt>Service</dt>
            <dd>{name}</dd>
          </div>
          <div>
            <dt>Estimate</dt>
            <dd>{hasPrice ? `${money(min)} – ${money(max)}` : "To be confirmed"}</dd>
          </div>
          <div>
            <dt>Delivery</dt>
            <dd>{delivery ?? "To be confirmed"}</dd>
          </div>
        </dl>
      )}

      <label className="chat-label" htmlFor="chat-message">
        Your message
      </label>
      <textarea
        id="chat-message"
        className="chat-text"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="What are you building, and when do you need it?"
      />

      <div className="chat-actions">
        <a className="btn btn-primary" href={mailto}>
          Send by email
        </a>
        <Link className="btn btn-ghost" href="/#services">
          Back to services
        </Link>
      </div>
    </div>
  );
}

export default function ChatPage() {
  return (
    <>
      <SiteNav base="/" />
      <main className="chat-page">
        <div className="container">
          <Suspense fallback={null}>
            <ChatForm />
          </Suspense>
        </div>
      </main>
      <SiteFooter base="/" />
    </>
  );
}
