"use client";

/**
 * Corkboard of testimonials: client reviews as sticky notes that visitors can drag around.
 * One self-contained component. No other files, no libraries.
 *
 * Usage (Next.js App Router):
 *   import CorkboardTestimonials from "./CorkboardTestimonials";
 *   <CorkboardTestimonials ctaHref="#contact" />
 *
 * IMPORTANT: the reviews in SAMPLE_TESTIMONIALS are placeholders.
 * Replace them with real client reviews (ask permission first) before you launch.
 *
 * Works with mouse, touch and keyboard (focus a note, then use the arrow keys;
 * hold Shift to move faster).
 */

import { useRef, useState, type CSSProperties, type KeyboardEvent, type PointerEvent } from "react";

export type Testimonial = {
  quote: string;
  name: string;
  role: string;
  /** 1 to 5, defaults to 5 */
  rating?: number;
};

// SAMPLE DATA: replace with real client reviews. Keep each quote under ~110 characters
// so it fits on a note.
const SAMPLE_TESTIMONIALS: Testimonial[] = [
  { quote: "They shipped our app two weeks early and it just worked.", name: "Alex M.", role: "Founder, fintech startup, UK" },
  { quote: "Great communication across time zones. We always knew what was happening.", name: "Sarah K.", role: "Product lead, USA" },
  { quote: "Our website loads in under a second now. Customers noticed.", name: "Omar R.", role: "Owner, online store, UAE" },
  { quote: "They built the game prototype faster than we could write the brief.", name: "Lena V.", role: "Indie game studio, Germany" },
  { quote: "Fair price, honest advice, and no surprise bills.", name: "Daniel P.", role: "Operations, Canada" },
  { quote: "They told us what NOT to build, and saved us months.", name: "Mia T.", role: "CEO, SaaS company, Australia" },
  { quote: "Clean Go backend. Our own team took it over with zero stress.", name: "Noah B.", role: "CTO, Netherlands" },
  { quote: "Our app feels fast on every phone we tested.", name: "Aisha H.", role: "Founder, Saudi Arabia" },
];

const NOTE_COLORS = ["#ffe98a", "#ffb9cb", "#b8e2ff", "#c5f0b1", "#ffd1a1", "#e2cbff"];
const PIN_COLORS = ["#e5484d", "#3b82f6", "#f5b700", "#22a559"];

type Pos = { fx: number; fy: number };

const clamp = (n: number) => Math.min(1, Math.max(0, n));

// Deterministic 0..1 value, so server and client render the same first layout
function jitter(i: number, k: number) {
  const s = Math.sin(i * 12.9898 + k * 78.233) * 43758.5453;
  return s - Math.floor(s);
}

function tidyLayout(n: number): Pos[] {
  const cols = Math.min(4, n);
  const rows = Math.ceil(n / cols);
  return Array.from({ length: n }, (_, i) => {
    const c = i % cols;
    const r = Math.floor(i / cols);
    const fx = cols === 1 ? 0.5 : 0.03 + (0.94 * c) / (cols - 1) + (jitter(i, 1) - 0.5) * 0.06;
    const fy = rows === 1 ? 0.5 : 0.05 + (0.9 * r) / (rows - 1) + (jitter(i, 2) - 0.5) * 0.08;
    return { fx: clamp(fx), fy: clamp(fy) };
  });
}

const rotationFor = (i: number) => ((i * 7 + 3) % 9 - 4) * 1.1; // about -4.4 to 4.4 degrees

type Props = {
  testimonials?: Testimonial[];
  eyebrow?: string;
  title?: string;
  subtitle?: string;
  /** where the "Start a project" link goes */
  ctaHref?: string;
};

export default function CorkboardTestimonials({
  testimonials = SAMPLE_TESTIMONIALS,
  eyebrow = "Client reviews",
  title = "What our clients say",
  subtitle = "Drag the notes around. It's your board now.",
  ctaHref = "#contact",
}: Props) {
  const n = testimonials.length;
  const boardRef = useRef<HTMLDivElement>(null);
  const zTop = useRef(n + 1);
  const drag = useRef<{ i: number; id: number; sx: number; sy: number; fx: number; fy: number } | null>(null);

  const [pos, setPos] = useState<Pos[]>(() => tidyLayout(n));
  const [z, setZ] = useState<number[]>(() => Array.from({ length: n }, (_, i) => i + 1));
  const [active, setActive] = useState<number | null>(null);

  function bringToFront(i: number) {
    zTop.current += 1;
    const top = zTop.current;
    setZ((prev) => prev.map((v, k) => (k === i ? top : v)));
  }

  function onPointerDown(e: PointerEvent<HTMLElement>, i: number) {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    drag.current = { i, id: e.pointerId, sx: e.clientX, sy: e.clientY, fx: pos[i].fx, fy: pos[i].fy };
    setActive(i);
    bringToFront(i);
  }

  function onPointerMove(e: PointerEvent<HTMLElement>, i: number) {
    const d = drag.current;
    const board = boardRef.current;
    if (!d || d.i !== i || d.id !== e.pointerId || !board) return;
    const el = e.currentTarget;
    const rangeX = Math.max(1, board.clientWidth - el.offsetWidth);
    const rangeY = Math.max(1, board.clientHeight - el.offsetHeight);
    const fx = clamp(d.fx + (e.clientX - d.sx) / rangeX);
    const fy = clamp(d.fy + (e.clientY - d.sy) / rangeY);
    setPos((prev) => prev.map((p, k) => (k === i ? { fx, fy } : p)));
  }

  function endDrag(e: PointerEvent<HTMLElement>) {
    if (drag.current && drag.current.id === e.pointerId) {
      drag.current = null;
      setActive(null);
    }
  }

  function onKeyDown(e: KeyboardEvent<HTMLElement>, i: number) {
    const board = boardRef.current;
    if (!board) return;
    const step = e.shiftKey ? 40 : 14;
    const rangeX = Math.max(1, board.clientWidth - e.currentTarget.offsetWidth);
    const rangeY = Math.max(1, board.clientHeight - e.currentTarget.offsetHeight);
    let dx = 0;
    let dy = 0;
    if (e.key === "ArrowLeft") dx = -step;
    else if (e.key === "ArrowRight") dx = step;
    else if (e.key === "ArrowUp") dy = -step;
    else if (e.key === "ArrowDown") dy = step;
    else return;
    e.preventDefault();
    bringToFront(i);
    setPos((prev) =>
      prev.map((p, k) => (k === i ? { fx: clamp(p.fx + dx / rangeX), fy: clamp(p.fy + dy / rangeY) } : p)),
    );
  }

  return (
    <section className="cb-root" aria-label="Client testimonials">
      <style dangerouslySetInnerHTML={{ __html: CSS }} />

      <header className="cb-head">
        <span className="cb-eyebrow">{eyebrow}</span>
        <h2>{title}</h2>
        <p>{subtitle}</p>
      </header>

      <div className="cb-frame">
        <div className="cb-board" ref={boardRef}>
          {testimonials.map((t, i) => {
            const rating = Math.min(5, Math.max(1, t.rating ?? 5));
            const style = {
              "--fx": pos[i].fx,
              "--fy": pos[i].fy,
              "--rot": `${rotationFor(i)}deg`,
              "--note": NOTE_COLORS[i % NOTE_COLORS.length],
              "--pin": PIN_COLORS[i % PIN_COLORS.length],
              zIndex: z[i],
            } as CSSProperties;
            return (
              <article
                key={`${i}-${t.name}`}
                className={`cb-note${active === i ? " cb-dragging" : ""}`}
                style={style}
                tabIndex={0}
                aria-label={`Review from ${t.name} (arrow keys move this note)`}
                onPointerDown={(e) => onPointerDown(e, i)}
                onPointerMove={(e) => onPointerMove(e, i)}
                onPointerUp={endDrag}
                onPointerCancel={endDrag}
                onKeyDown={(e) => onKeyDown(e, i)}
              >
                <span className="cb-pin" aria-hidden="true" />
                <blockquote className="cb-quote">{t.quote}</blockquote>
                <footer className="cb-by">
                  <span className="cb-stars" role="img" aria-label={`${rating} out of 5 stars`}>
                    {"★".repeat(rating)}
                    <span className="cb-stars-off">{"★".repeat(5 - rating)}</span>
                  </span>
                  <strong className="cb-name">{t.name}</strong>
                  <span className="cb-role">{t.role}</span>
                </footer>
              </article>
            );
          })}
        </div>
      </div>

      <div className="cb-actions">
        <a className="cb-btn cb-primary" href={ctaHref}>
          Start a project
        </a>
      </div>
    </section>
  );
}

const CORK_NOISE =
  "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='220' height='220'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='3' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 .36  0 0 0 0 .22  0 0 0 0 .1  0 0 0 .7 0'/></filter><rect width='220' height='220' filter='url(%23n)'/></svg>\")";

const CSS = `
@import url("https://fonts.googleapis.com/css2?family=Caveat+Brush&family=Outfit:wght@400;500;600;700&family=Patrick+Hand&display=swap");

.cb-root {
  --cb-wood: #a0713f;
  --cb-wood-deep: #6b4724;
  --cb-cork: #c79a63;
  --cb-ink: #2b2a1c;
  --cb-head: "Caveat Brush", "Segoe Print", "Comic Sans MS", cursive;
  --cb-body: "Patrick Hand", "Segoe Print", "Comic Sans MS", cursive;
  --cb-ui: "Outfit", "Segoe UI", system-ui, sans-serif;
  --cb-nw: 214px;
  --cb-nh: 214px;
  max-width: 1080px;
  margin: 0 auto;
  padding: 24px 14px 32px;
  font-family: var(--cb-body);
  font-size: 20px;
  line-height: 1.3;
}
.cb-root *, .cb-root *::before, .cb-root *::after { box-sizing: border-box; }

.cb-head { text-align: center; margin-bottom: 28px; }
.cb-eyebrow { display: block; margin-bottom: 12px; font-family: var(--cb-ui); font-size: 12px; font-weight: 600; letter-spacing: 0.16em; text-transform: uppercase; color: #566079; }
.cb-head h2 {
  font-family: var(--cb-ui);
  font-weight: 600;
  font-size: clamp(30px, 4.6vw, 44px);
  line-height: 1.08;
  letter-spacing: -0.03em;
  margin: 0 0 12px;
  color: #0f1b2d;
}
.cb-head p { margin: 0 auto; max-width: 520px; font-family: var(--cb-ui); font-size: 16px; line-height: 1.45; color: #566079; }

.cb-frame {
  padding: 14px;
  border-radius: 8px;
  background: linear-gradient(135deg, var(--cb-wood) 0%, var(--cb-wood-deep) 55%, var(--cb-wood) 100%);
  box-shadow: 0 18px 30px rgba(0, 0, 0, 0.28);
}

.cb-board {
  position: relative;
  overflow: hidden;
  min-height: 640px;
  border-radius: 3px;
  background:
    ${CORK_NOISE},
    radial-gradient(ellipse at 20% 15%, rgba(255, 235, 200, 0.35), transparent 55%),
    radial-gradient(ellipse at 85% 90%, rgba(80, 45, 15, 0.3), transparent 55%),
    var(--cb-cork);
  box-shadow: inset 0 0 40px rgba(60, 32, 8, 0.55);
}

.cb-note {
  position: absolute;
  left: calc((100% - var(--cb-nw)) * var(--fx));
  top: calc((100% - var(--cb-nh)) * var(--fy));
  width: var(--cb-nw);
  height: var(--cb-nh);
  padding: 28px 14px 12px;
  display: flex;
  flex-direction: column;
  color: var(--cb-ink);
  background: linear-gradient(transparent 68%, rgba(0, 0, 0, 0.07)), var(--note);
  box-shadow: 2px 9px 14px rgba(40, 20, 0, 0.32);
  transform: rotate(var(--rot));
  transition: transform 0.18s ease, box-shadow 0.18s ease;
  cursor: grab;
  touch-action: none;
  user-select: none;
  -webkit-user-select: none;
}
.cb-note.cb-dragging { cursor: grabbing; transform: rotate(0deg) scale(1.06); box-shadow: 6px 18px 26px rgba(40, 20, 0, 0.42); }
.cb-note:focus-visible { outline: 3px solid #1d4ed8; outline-offset: 3px; }

.cb-pin {
  position: absolute;
  top: -7px;
  left: 50%;
  width: 18px;
  height: 18px;
  margin-left: -9px;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 30%, rgba(255, 255, 255, 0.85) 0 10%, var(--pin) 38%, rgba(0, 0, 0, 0.35) 140%);
  box-shadow: 0 4px 5px rgba(0, 0, 0, 0.4);
}

.cb-quote {
  flex: 1;
  margin: 0;
  font-size: 20px;
  line-height: 1.22;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 6;
  -webkit-box-orient: vertical;
}
.cb-by { display: block; margin-top: 8px; }
.cb-stars { display: block; font-size: 16px; line-height: 1; letter-spacing: 1px; color: #d98a00; }
.cb-stars-off { color: rgba(43, 42, 28, 0.22); }
.cb-name { display: block; font-family: var(--cb-head); font-weight: 400; font-size: 23px; line-height: 1.1; margin-top: 3px; }
.cb-role { display: block; font-size: 15px; line-height: 1.15; opacity: 0.72; }

.cb-actions { display: flex; flex-wrap: wrap; justify-content: center; gap: 12px; margin-top: 28px; }
.cb-btn {
  font-family: var(--cb-ui);
  font-size: 16px;
  font-weight: 600;
  line-height: 1.2;
  color: inherit;
  background: transparent;
  border: 2px solid currentColor;
  border-radius: 999px;
  padding: 12px 26px;
  min-height: 48px;
  display: inline-flex;
  align-items: center;
  text-decoration: none;
  cursor: pointer;
  transition: background 0.15s ease, color 0.15s ease;
}
.cb-btn:hover { background: var(--cb-ink); color: #fff; border-color: var(--cb-ink); }
.cb-btn.cb-primary { background: #2b4eff; border-color: #2b4eff; color: #fff; }
.cb-btn.cb-primary:hover { background: #1b38d6; border-color: #1b38d6; color: #fff; }
.cb-btn:focus-visible { outline: 3px solid #1d4ed8; outline-offset: 3px; }

@media (max-width: 700px) {
  .cb-root { --cb-nw: 172px; --cb-nh: 190px; padding: 18px 10px 28px; }
  .cb-board { min-height: 880px; }
  .cb-note { padding: 26px 11px 10px; }
  .cb-quote { font-size: 17px; -webkit-line-clamp: 5; }
  .cb-name { font-size: 20px; }
  .cb-role { font-size: 14px; }
}

@media (prefers-reduced-motion: reduce) {
  .cb-note { transition: none; }
}
`;
