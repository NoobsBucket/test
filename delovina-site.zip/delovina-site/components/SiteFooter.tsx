import Link from "next/link";
import { SITE } from "../site.config";

export default function SiteFooter({ base = "" }: { base?: string }) {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <Link className="logo" href={base || "#top"}>
          <span className="logo-mark" aria-hidden="true" />
          {SITE.name}
        </Link>

        <ul className="footer-links">
          {SITE.nav.map((n) => (
            <li key={n.id}>
              <Link href={`${base}${n.href}`}>{n.label}</Link>
            </li>
          ))}
          <li>
            <a href={`mailto:${SITE.email}`}>{SITE.email}</a>
          </li>
        </ul>

        <p className="footer-legal">
          &copy; {new Date().getFullYear()} {SITE.name}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
