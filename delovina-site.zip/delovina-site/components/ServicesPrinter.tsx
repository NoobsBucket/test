"use client";

/**
 * Services printer (refined edition).
 * The visitor presses a service key on the printer. It prints a "United States of Delovina"
 * service passport card that slides out of the slot, with the price range and delivery time.
 * Click the card to flip it over.
 *
 * Beside the card (below it on small screens) there are three buttons:
 *   - Chat about this    opens your chat page with the selected service in the URL
 *   - Download card      saves a PNG of the card, front and back, at real ID-card size
 *   - Flip card
 *
 * One self-contained component. No other files, no libraries.
 *
 * Usage (Next.js App Router):
 *   import ServicesPrinter from "./ServicesPrinter";
 *   <ServicesPrinter chatHref="/chat" />
 *
 * IMPORTANT: the prices and timelines in SERVICES are placeholders.
 * Put in your own real numbers before you launch.
 *
 * What your chat page receives, as query parameters:
 *   /chat?service=website&name=Website&min=500&max=3000&currency=USD
 *        &delivery=1+to+4+weeks&message=Hi%21+I%27m+interested...
 *
 * The card is a fictional "country" card made for fun. It uses no real government
 * symbols, so keep it that way.
 */

import { useEffect, useRef, useState, type CSSProperties } from "react";

/* ---------- Content (edit me) ---------- */

export type Service = {
  id: string;
  /** 3 letters used in the card number, for example WEB */
  code: string;
  name: string;
  tagline: string;
  /** price range in USD */
  min: number;
  max: number;
  /** delivery time in weeks */
  weeksMin: number;
  weeksMax: number;
  /** the first 3 are shown on the card */
  includes: string[];
  tech: string[];
  /** accent color of the card photo and top band */
  color: string;
};

const SERVICES: Service[] = [
  {
    id: "website",
    code: "WEB",
    name: "Website",
    tagline: "Fast, good-looking sites that bring in clients.",
    min: 500,
    max: 3000,
    weeksMin: 1,
    weeksMax: 4,
    includes: ["Responsive design for phones and desktops", "SEO basics and fast loading", "Contact form and analytics"],
    tech: ["Next.js", "React", "Tailwind CSS", "Cloudflare"],
    color: "#1e3a8a",
  },
  {
    id: "mobile-app",
    code: "APP",
    name: "Mobile App",
    tagline: "iOS and Android apps from one codebase.",
    min: 3000,
    max: 15000,
    weeksMin: 6,
    weeksMax: 14,
    includes: ["iOS and Android from one codebase", "Login, push notifications, payments", "App Store and Google Play launch help"],
    tech: ["React Native", "Expo", "Go", "PostgreSQL"],
    color: "#0f766e",
  },
  {
    id: "game",
    code: "GME",
    name: "Game",
    tagline: "Playable games for phones, web and PC.",
    min: 4000,
    max: 30000,
    weeksMin: 8,
    weeksMax: 24,
    includes: ["A playable prototype first", "2D or 3D, on mobile, web or PC", "Multiplayer and leaderboards if needed"],
    tech: ["Unity", "Godot", "C#", "Blender"],
    color: "#5b21b6",
  },
  {
    id: "full-stack",
    code: "FST",
    name: "Full-stack App",
    tagline: "Everything from the screen to the database.",
    min: 5000,
    max: 25000,
    weeksMin: 8,
    weeksMax: 16,
    includes: ["Frontend, backend and database", "Admin panel and user accounts", "Deployment and monitoring"],
    tech: ["React", "Next.js", "Go", "PostgreSQL", "AWS"],
    color: "#9a5b0b",
  },
  {
    id: "frontend-ui",
    code: "FUI",
    name: "Frontend / UI",
    tagline: "Interfaces people enjoy using.",
    min: 800,
    max: 5000,
    weeksMin: 2,
    weeksMax: 6,
    includes: ["Design in Figma, then build", "Reusable components", "Accessible and fast on every screen"],
    tech: ["React", "Next.js", "TypeScript", "Tailwind CSS", "Figma"],
    color: "#9d174d",
  },
  {
    id: "backend-api",
    code: "API",
    name: "Backend / API",
    tagline: "APIs and databases that stay up.",
    min: 1500,
    max: 10000,
    weeksMin: 3,
    weeksMax: 10,
    includes: ["REST or GraphQL API", "Database design and migrations", "Auth, logging and deployment"],
    tech: ["Go", "PostgreSQL", "Redis", "Docker"],
    color: "#166534",
  },
];

/* ---------- Helpers ---------- */

const PRINT_MS = 2400;

const money = (n: number) => `$${n.toLocaleString("en-US")}`;
const weeksText = (s: Service) =>
  s.weeksMin === s.weeksMax ? `${s.weeksMin} weeks` : `${s.weeksMin} to ${s.weeksMax} weeks`;
const priceText = (s: Service) => `${money(s.min)} to ${money(s.max)}`;

function chatUrl(base: string, s: Service) {
  const message = `Hi! I'm interested in a ${s.name}. Your estimate says ${priceText(s)} and ${weeksText(s)}. Here's what I need: `;
  const params = new URLSearchParams({
    service: s.id,
    name: s.name,
    min: String(s.min),
    max: String(s.max),
    currency: "USD",
    delivery: weeksText(s),
    message,
  });
  return `${base}${base.includes("?") ? "&" : "?"}${params.toString()}`;
}

type CardMeta = { id: string; issued: string; mrz: [string, string, string] };

function cardMeta(s: Service, company: string, issued: Date): CardMeta {
  const mm = String(issued.getMonth() + 1).padStart(2, "0");
  const dd = String(issued.getDate()).padStart(2, "0");
  const yy = String(issued.getFullYear()).slice(2);
  const prefix = company.replace(/[^A-Za-z]/g, "").slice(0, 3).toUpperCase() || "DLV";
  const clean = (t: string) => t.toUpperCase().replace(/[^A-Z0-9]+/g, "<");
  const fill = (t: string, n = 30) => (t + "<".repeat(n)).slice(0, n);
  return {
    id: `${prefix}-${mm}${dd}-${s.code}`,
    issued: issued.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }),
    mrz: [
      fill(`I<${prefix}${mm}${dd}${s.code}<<`),
      fill(`${yy}${mm}${dd}<${s.min}<${s.max}<${s.weeksMin}W${s.weeksMax}`),
      fill(clean(s.name)),
    ],
  };
}

/** Decorative barcode bars, the same for a given ID on screen and in the download */
function barcodeBars(id: string, width: number) {
  const seq: number[] = [];
  for (const ch of id + id) {
    const n = ch.charCodeAt(0);
    seq.push(1 + (n % 3), 1 + ((n >> 1) % 2));
  }
  const unit = width / seq.reduce((a, b) => a + b, 0);
  const bars: { x: number; w: number }[] = [];
  let x = 0;
  seq.forEach((w, i) => {
    if (i % 2 === 0) bars.push({ x, w: w * unit });
    x += w * unit;
  });
  return bars;
}

/** Fine wavy lines behind the card, like the security pattern on a passport */
const WAVES: string[] = Array.from({ length: 14 }, (_, k) => {
  const amp = 8 + (k % 4) * 3;
  const freq = 0.018 + (k % 3) * 0.004;
  const phase = k * 0.9;
  const y0 = 8 + k * 21;
  let d = "";
  for (let x = 0; x <= 460; x += 6) {
    const y = y0 + Math.sin(x * freq + phase) * amp + Math.sin(x * freq * 2.3 + phase * 1.7) * amp * 0.4;
    d += `${x === 0 ? "M" : "L"}${x} ${y.toFixed(1)} `;
  }
  return d;
});

/** Tick marks around the seal, centered on 0,0 */
const SEAL_TICKS = Array.from({ length: 24 }, (_, i) => {
  const a = (i / 24) * Math.PI * 2;
  const p = (r: number) => `${(Math.cos(a) * r).toFixed(2)} ${(Math.sin(a) * r).toFixed(2)}`;
  return `M${p(14.5)} L${p(18.5)}`;
}).join(" ");

/* ---------- Icons (one source for the page and the downloaded card) ---------- */

const ICONS: Record<string, string> = {
  website:
    "M10 10h28a4 4 0 0 1 4 4v20a4 4 0 0 1-4 4H10a4 4 0 0 1-4-4V14a4 4 0 0 1 4-4z M6 19h36 M12 14.5h.01 M17 14.5h.01",
  "mobile-app": "M19 5h10a5 5 0 0 1 5 5v28a5 5 0 0 1-5 5H19a5 5 0 0 1-5-5V10a5 5 0 0 1 5-5z M21 37h6",
  game: "M15 15h18a11 11 0 0 1 0 22H15a11 11 0 0 1 0-22z M14 22v8 M10 26h8 M32 24h.01 M37 29h.01",
  "full-stack": "M24 7l18 9-18 9-18-9z M6 24l18 9 18-9 M6 32l18 9 18-9",
  "frontend-ui": "M17 15L8 24l9 9 M31 15l9 9-9 9 M27 11l-6 26",
  "backend-api":
    "M11 7h26a3 3 0 0 1 3 3v4a3 3 0 0 1-3 3H11a3 3 0 0 1-3-3v-4a3 3 0 0 1 3-3z M11 19h26a3 3 0 0 1 3 3v4a3 3 0 0 1-3 3H11a3 3 0 0 1-3-3v-4a3 3 0 0 1 3-3z M11 31h26a3 3 0 0 1 3 3v4a3 3 0 0 1-3 3H11a3 3 0 0 1-3-3v-4a3 3 0 0 1 3-3z M14 12h.01 M14 24h.01 M14 36h.01",
  fallback: "M12 8h24a4 4 0 0 1 4 4v24a4 4 0 0 1-4 4H12a4 4 0 0 1-4-4V12a4 4 0 0 1 4-4z",
};
const iconPath = (id: string) => ICONS[id] ?? ICONS.fallback;

function ServiceIcon({ id, color = "#fff", size = 36 }: { id: string; color?: string; size?: number }) {
  return (
    <svg viewBox="0 0 48 48" width={size} height={size} aria-hidden="true" focusable="false" fill="none" stroke={color} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round">
      <path d={iconPath(id)} />
    </svg>
  );
}

function ChatIcon() {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 5h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H11l-5 4v-4H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z" />
    </svg>
  );
}

/* ---------- Download: the card as a PNG, front and back ---------- */

const REF_W = 460; // the card is designed on a 460 x 290 grid
const REF_H = 290;
const OUT_W = 1012; // 3.375 in at 300 dpi, the size of a real ID card
const OUT_H = 638;
const FONT = "Outfit, 'Segoe UI', system-ui, sans-serif";
const SERIF = "Newsreader, Georgia, 'Times New Roman', serif";
const MONO = "Menlo, Consolas, 'Courier New', monospace";
const INK = "#0b1b3a";
const MUTED = "#566079";

type Ctx = CanvasRenderingContext2D;

function rrect(c: Ctx, x: number, y: number, w: number, h: number, r: number) {
  c.beginPath();
  c.moveTo(x + r, y);
  c.arcTo(x + w, y, x + w, y + h, r);
  c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r);
  c.arcTo(x, y, x + w, y, r);
  c.closePath();
}

function txt(c: Ctx, t: string, x: number, y: number, size: number, weight: number | string, color: string, align: CanvasTextAlign = "left", family = FONT) {
  c.font = `${weight} ${size}px ${family}`;
  c.fillStyle = color;
  c.textAlign = align;
  c.textBaseline = "top";
  c.fillText(t, x, y);
}

/** text with letter spacing, drawn one letter at a time so it works in every browser */
function spaced(c: Ctx, t: string, x: number, y: number, size: number, weight: number | string, color: string, sp: number, family = FONT) {
  c.font = `${weight} ${size}px ${family}`;
  c.fillStyle = color;
  c.textAlign = "left";
  c.textBaseline = "top";
  let cx = x;
  for (const ch of t) {
    c.fillText(ch, cx, y);
    cx += c.measureText(ch).width + sp;
  }
}

/** small uppercase field label */
function lab(c: Ctx, t: string, x: number, y: number) {
  spaced(c, t.toUpperCase(), x, y, 9, 500, MUTED, 1);
}

function fit(c: Ctx, t: string, maxW: number, size: number, weight: number | string, family = FONT) {
  let s = size;
  c.font = `${weight} ${s}px ${family}`;
  while (s > 9 && c.measureText(t).width > maxW) {
    s -= 0.5;
    c.font = `${weight} ${s}px ${family}`;
  }
  return s;
}

function ellipsize(c: Ctx, t: string, maxW: number) {
  if (c.measureText(t).width <= maxW) return t;
  let s = t;
  while (s.length > 1 && c.measureText(s + "...").width > maxW) s = s.slice(0, -1);
  return s.trimEnd() + "...";
}

function drawIcon(c: Ctx, id: string, x: number, y: number, size: number, color: string) {
  c.save();
  c.translate(x, y);
  c.scale(size / 48, size / 48);
  c.strokeStyle = color;
  c.lineWidth = 2.6;
  c.lineCap = "round";
  c.lineJoin = "round";
  c.stroke(new Path2D(iconPath(id)));
  c.restore();
}

function drawSeal(c: Ctx, cx: number, cy: number, letter: string) {
  c.save();
  c.translate(cx, cy);
  c.strokeStyle = INK;
  c.lineWidth = 1.3;
  c.beginPath();
  c.arc(0, 0, 20, 0, Math.PI * 2);
  c.stroke();
  c.beginPath();
  c.arc(0, 0, 12.5, 0, Math.PI * 2);
  c.stroke();
  c.lineWidth = 1.2;
  c.lineCap = "butt";
  c.stroke(new Path2D(SEAL_TICKS));
  txt(c, letter, 0, -8.5, 16, 600, INK, "center", SERIF);
  c.restore();
}

function drawBase(c: Ctx, color: string) {
  c.save();
  rrect(c, 0, 0, REF_W, REF_H, 18);
  c.clip();
  c.fillStyle = "#f3f1ea";
  c.fillRect(0, 0, REF_W, REF_H);
  c.fillStyle = color;
  c.fillRect(0, 0, REF_W, 6);
  c.lineWidth = 1.1;
  c.lineCap = "butt";
  WAVES.forEach((d, i) => {
    c.strokeStyle = i % 2 === 0 ? "rgba(11,27,58,0.075)" : "rgba(11,27,58,0.04)";
    c.stroke(new Path2D(d));
  });
  c.restore();
  rrect(c, 5, 5, REF_W - 10, REF_H - 10, 14);
  c.lineWidth = 1;
  c.strokeStyle = "rgba(11,27,58,0.12)";
  c.stroke();
}

function drawFront(c: Ctx, s: Service, company: string, country: string, title: string, meta: CardMeta) {
  drawBase(c, s.color);
  spaced(c, country.toUpperCase(), 28, 22, 13, 600, INK, 1.6, SERIF);
  spaced(c, title.toUpperCase(), 28, 40, 10, 500, MUTED, 1.8);
  drawSeal(c, 410, 40, (company[0] || "D").toUpperCase());

  // "photo" with the service icon
  rrect(c, 28, 70, 108, 128, 6);
  c.fillStyle = s.color;
  c.fill();
  rrect(c, 29, 71, 106, 126, 5);
  c.lineWidth = 1.5;
  c.strokeStyle = "rgba(255,255,255,0.35)";
  c.stroke();
  drawIcon(c, s.id, 28 + 22, 70 + 32, 64, "#ffffff");

  // faded second photo, like a real passport card
  c.save();
  c.globalAlpha = 0.16;
  rrect(c, 352, 88, 80, 100, 4);
  c.fillStyle = s.color;
  c.fill();
  drawIcon(c, s.id, 352 + 18, 88 + 28, 44, "#ffffff");
  c.restore();

  // fields
  lab(c, "Service", 152, 70);
  txt(c, s.name, 152, 84, fit(c, s.name, 280, 28, 600, SERIF), 600, INK, "left", SERIF);
  lab(c, "Estimated price", 152, 118);
  const price = `${money(s.min)} \u2013 ${money(s.max)}`;
  txt(c, price, 152, 132, fit(c, price, 190, 20, 600), 600, INK);
  lab(c, "Delivery time", 152, 160);
  const wk = weeksText(s);
  txt(c, wk, 152, 174, fit(c, wk, 190, 20, 600), 600, INK);

  lab(c, "Card no.", 28, 206);
  txt(c, meta.id, 28, 220, 14, 600, INK);
  lab(c, "Date of issue", 168, 206);
  txt(c, meta.issued, 168, 220, 14, 600, INK);

  // foil patch
  rrect(c, 352, 206, 80, 32, 4);
  c.fillStyle = "#d8d2c2";
  c.fill();
  c.lineWidth = 1;
  c.strokeStyle = "rgba(11,27,58,0.18)";
  c.stroke();
  txt(c, (company[0] || "D").toUpperCase(), 392, 213, 18, 600, "rgba(11,27,58,0.45)", "center", SERIF);

  c.font = `400 13px ${FONT}`;
  txt(c, ellipsize(c, s.tagline, 404), 28, 252, 13, 400, MUTED);
}

function drawBack(c: Ctx, s: Service, company: string, country: string, meta: CardMeta) {
  drawBase(c, s.color);
  spaced(c, country.toUpperCase(), 28, 22, 11, 600, INK, 1.4, SERIF);
  spaced(c, "WHAT'S INCLUDED", 28, 46, 9, 600, MUTED, 1);

  s.includes.slice(0, 3).forEach((t, i) => {
    const y = 68 + i * 21;
    c.beginPath();
    c.moveTo(29.2, y + 7.8);
    c.lineTo(32.7, y + 11.3);
    c.lineTo(39.8, y + 4.2);
    c.lineWidth = 2.2;
    c.lineCap = "butt";
    c.lineJoin = "miter";
    c.strokeStyle = s.color;
    c.stroke();
    c.font = `400 14px ${FONT}`;
    txt(c, ellipsize(c, t, 380), 50, y, 14, 400, INK);
  });

  // technology chips, one row
  let x = 28;
  for (const t of s.tech) {
    c.font = `500 12px ${FONT}`;
    const w = c.measureText(t).width + 22;
    if (x + w > 432) break;
    rrect(c, x, 138, w, 22, 4);
    c.fillStyle = "rgba(255,255,255,0.6)";
    c.fill();
    c.lineWidth = 1;
    c.strokeStyle = "rgba(11,27,58,0.14)";
    c.stroke();
    txt(c, t, x + 11, 143, 12, 500, INK);
    x += w + 6;
  }

  c.font = `400 11.5px ${FONT}`;
  txt(c, ellipsize(c, "Estimate only. The final price depends on your scope.", 404), 28, 176, 11.5, 400, MUTED);

  // machine readable zone, three lines like a passport card
  c.save();
  rrect(c, 0, 0, REF_W, REF_H, 18);
  c.clip();
  c.fillStyle = "rgba(11,27,58,0.06)";
  c.fillRect(0, 198, REF_W, 92);
  c.restore();
  meta.mrz.forEach((line, i) => txt(c, line, 28, 208 + i * 21, 14, 400, INK, "left", MONO));
  c.fillStyle = INK;
  for (const b of barcodeBars(meta.id, 116)) c.fillRect(316 + b.x, 212, Math.max(b.w, 0.8), 56);
  void company;
}

async function buildCardSheet(s: Service, company: string, country: string, title: string, issued: Date): Promise<Blob> {
  try {
    if (document.fonts) {
      await Promise.all([
        ...["400", "500", "600"].map((w) => document.fonts.load(`${w} 20px Outfit`)),
        document.fonts.load("600 20px Newsreader"),
      ]);
    }
  } catch {
    /* fall back to system fonts */
  }
  const pad = 80;
  const gap = 70;
  const W = pad * 2 + OUT_W * 2 + gap;
  const H = pad * 2 + OUT_H;
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const c = canvas.getContext("2d");
  if (!c) throw new Error("Canvas is not available");

  c.fillStyle = "#eceef1";
  c.fillRect(0, 0, W, H);

  const meta = cardMeta(s, company, issued);
  const k = OUT_W / REF_W;
  [0, 1].forEach((side) => {
    const ox = pad + side * (OUT_W + gap);
    c.save();
    c.shadowColor = "rgba(11,27,58,0.28)";
    c.shadowBlur = 50;
    c.shadowOffsetY = 18;
    rrect(c, ox, pad, OUT_W, OUT_H, 18 * k);
    c.fillStyle = "#f3f1ea";
    c.fill();
    c.restore();
    c.save();
    c.translate(ox, pad);
    c.scale(k, k);
    if (side === 0) drawFront(c, s, company, country, title, meta);
    else drawBack(c, s, company, country, meta);
    c.restore();
  });

  return new Promise((resolve, reject) => {
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("Could not create the image"))), "image/png");
  });
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/* ---------- The card on the page ---------- */

function Waves() {
  return (
    <svg className="pr-waves" viewBox="0 0 460 290" preserveAspectRatio="none" aria-hidden="true">
      {WAVES.map((d, i) => (
        <path key={i} d={d} />
      ))}
    </svg>
  );
}

function PassportCard({
  s,
  company,
  country,
  title,
  meta,
  flipped,
}: {
  s: Service;
  company: string;
  country: string;
  title: string;
  meta: CardMeta;
  flipped: boolean;
}) {
  const bars = barcodeBars(meta.id, 116);
  const initial = (company[0] || "D").toUpperCase();
  const vars = { "--c": s.color } as CSSProperties;
  return (
    <div className="pr-idwrap">
      <div className={`pr-idinner${flipped ? " pr-flipped" : ""}`}>
        {/* front */}
        <div className="pr-face pr-front" style={vars} aria-hidden={flipped}>
          <Waves />
          <span className="pr-f-country">{country}</span>
          <span className="pr-f-title">{title}</span>
          <svg className="pr-f-seal" viewBox="-22 -22 44 44" aria-hidden="true">
            <circle r="20" />
            <circle r="12.5" />
            <path d={SEAL_TICKS} />
            <text y="5.6" textAnchor="middle">
              {initial}
            </text>
          </svg>
          <span className="pr-f-photo">
            <ServiceIcon id={s.id} size={64} />
          </span>
          <span className="pr-f-ghost">
            <ServiceIcon id={s.id} size={44} />
          </span>
          <span className="pr-f-service">
            <span className="pr-lab">Service</span>
            <b>{s.name}</b>
          </span>
          <span className="pr-f-price">
            <span className="pr-lab">Estimated price</span>
            <b>
              {money(s.min)} – {money(s.max)}
            </b>
          </span>
          <span className="pr-f-time">
            <span className="pr-lab">Delivery time</span>
            <b>{weeksText(s)}</b>
          </span>
          <span className="pr-f-no">
            <span className="pr-lab">Card no.</span>
            <b>{meta.id}</b>
          </span>
          <span className="pr-f-issued">
            <span className="pr-lab">Date of issue</span>
            <b>{meta.issued}</b>
          </span>
          <span className="pr-f-holo">{initial}</span>
          <span className="pr-f-tag">{s.tagline}</span>
        </div>

        {/* back */}
        <div className="pr-face pr-back" style={vars} aria-hidden={!flipped}>
          <Waves />
          <span className="pr-b-country">{country}</span>
          <span className="pr-b-h">What&apos;s included</span>
          <ul className="pr-b-list">
            {s.includes.slice(0, 3).map((t) => (
              <li key={t}>{t}</li>
            ))}
          </ul>
          <ul className="pr-b-tech">
            {s.tech.map((t) => (
              <li key={t}>{t}</li>
            ))}
          </ul>
          <span className="pr-b-note">Estimate only. The final price depends on your scope.</span>
          <span className="pr-b-band" />
          <span className="pr-b-mrz">
            {meta.mrz[0]}
            <br />
            {meta.mrz[1]}
            <br />
            {meta.mrz[2]}
          </span>
          <svg className="pr-b-bars" viewBox="0 0 116 56" preserveAspectRatio="none" aria-hidden="true">
            {bars.map((b, i) => (
              <rect key={i} x={b.x} y={0} width={Math.max(b.w, 0.8)} height={56} />
            ))}
          </svg>
        </div>
      </div>
    </div>
  );
}

/* ---------- Component ---------- */

type Phase = "idle" | "printing" | "served";

type Props = {
  services?: Service[];
  /** your chat page. The selected service is added as query parameters. */
  chatHref?: string;
  eyebrow?: string;
  title?: string;
  subtitle?: string;
  companyName?: string;
  /** the name printed at the top of the card */
  countryName?: string;
  /** the line under the country name */
  cardTitle?: string;
};

export default function ServicesPrinter({
  services = SERVICES,
  chatHref = "/chat",
  eyebrow = "Service estimates",
  title = "Select a service to receive an estimate",
  subtitle = "Choose a service on the printer. Your service card is issued with a price range and delivery time.",
  companyName = "Delovina",
  countryName = "United States of Delovina",
  cardTitle = "Service passport card",
}: Props) {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [phase, setPhase] = useState<Phase>("idle");
  const [flipped, setFlipped] = useState(false);
  const [issued, setIssued] = useState<Date | null>(null);
  const [saving, setSaving] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => () => clearTimeout(timer.current), []);

  const selected = services.find((s) => s.id === selectedId) ?? null;
  const meta = selected && issued ? cardMeta(selected, companyName, issued) : null;

  function pick(s: Service) {
    if (phase === "printing") return;
    if (phase === "served" && s.id === selectedId) return;
    setSelectedId(s.id);
    setFlipped(false);
    setIssued(new Date());
    clearTimeout(timer.current);
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setPhase("served");
      return;
    }
    setPhase("printing");
    timer.current = setTimeout(() => setPhase("served"), PRINT_MS + 60);
  }

  async function download() {
    if (!selected || !issued || saving) return;
    setSaving(true);
    try {
      const blob = await buildCardSheet(selected, companyName, countryName, cardTitle, issued);
      downloadBlob(blob, `${companyName.toLowerCase()}-card-${selected.id}.png`);
    } finally {
      setSaving(false);
    }
  }

  const status =
    phase === "idle" ? "Ready. Select a service." : phase === "printing" ? "Issuing your card..." : "Complete. Please take your card.";

  return (
    <section className="pr-root" aria-label="Services printer" style={{ "--pr-ms": `${PRINT_MS}ms` } as CSSProperties}>
      <style dangerouslySetInnerHTML={{ __html: CSS }} />

      <header className="pr-head">
        <span className="pr-eyebrow">{eyebrow}</span>
        <h2>{title}</h2>
        <p>{subtitle}</p>
      </header>

      {/* ---------- The printer ---------- */}
      <div className="pr-printer">
        <div className="pr-paper" aria-hidden="true" />
        <div className="pr-body">
          <div className="pr-top">
            <span className="pr-brand">{companyName}</span>
            <span className="pr-model">
              <i className="pr-led" />
              Card printer
            </span>
          </div>

          <div className="pr-panel">
            <div className={`pr-lcd pr-${phase}`} aria-hidden="true">
              <span className="pr-lcd-text">
                <i className="pr-dot" />
                {status}
              </span>
              <span className="pr-bar">
                <i className={`pr-fill${phase === "printing" ? " pr-run" : ""}${phase === "served" ? " pr-done" : ""}`} />
              </span>
            </div>

            <div className="pr-keys">
              {services.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  className="pr-key"
                  aria-pressed={selectedId === s.id && phase !== "idle"}
                  aria-disabled={phase === "printing"}
                  onClick={() => pick(s)}
                >
                  <span className="pr-key-icon" style={{ "--c": s.color } as CSSProperties} aria-hidden="true">
                    <ServiceIcon id={s.id} size={16} />
                  </span>
                  <span>{s.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="pr-vents" aria-hidden="true">
            {Array.from({ length: 22 }, (_, i) => (
              <i key={i} />
            ))}
          </div>

          <div className="pr-slot" aria-hidden="true" />
        </div>
      </div>

      {/* ---------- The printed card ---------- */}
      <div className={`pr-out${selected ? " pr-has" : ""}`}>
        {selected && meta ? (
          <div className="pr-row">
            <span className="pr-spacer" aria-hidden="true" />
            <div className="pr-cardcol">
              <div
                className={`pr-feed${phase === "served" ? " pr-fed" : ""}`}
                key={`${selected.id}-${issued?.getTime()}`}
                onClick={() => phase === "served" && setFlipped((f) => !f)}
              >
                <PassportCard s={selected} company={companyName} country={countryName} title={cardTitle} meta={meta} flipped={flipped} />
              </div>
              <p className={`pr-hint${phase === "served" ? "" : " pr-wait"}`}>Click the card to flip it.</p>
            </div>

            <div className={`pr-side${phase === "served" ? "" : " pr-wait"}`}>
              <a className="pr-chat" href={chatUrl(chatHref, selected)} tabIndex={phase === "served" ? 0 : -1}>
                <ChatIcon />
                Chat about this
              </a>
              <button type="button" className="pr-ghostbtn" onClick={download} aria-busy={saving} disabled={phase !== "served"}>
                {saving ? "Preparing..." : "Download card"}
              </button>
              <button type="button" className="pr-ghostbtn" onClick={() => setFlipped((f) => !f)} aria-pressed={flipped} disabled={phase !== "served"}>
                Flip card
              </button>
            </div>
          </div>
        ) : (
          <div className="pr-empty">
            <p className="pr-empty-title">Your card will appear here</p>
            <p>Select a service on the printer to see its price range and delivery time.</p>
          </div>
        )}
      </div>

      <div className="pr-sr" aria-live="polite">
        {phase === "served" && selected ? `${selected.name}: ${priceText(selected)}, ${weeksText(selected)}.` : ""}
      </div>
    </section>
  );
}

/* ---------- Styles (scoped with the pr- prefix) ---------- */

const CSS = `
@import url("https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&family=Newsreader:wght@500;600&display=swap");

.pr-root {
  --pr-font: "Outfit", "Segoe UI", system-ui, sans-serif;
  --pr-serif: "Newsreader", Georgia, "Times New Roman", serif;
  --pr-mono: Menlo, Consolas, "Courier New", monospace;
  --pr-ink: #0b1b3a;
  --pr-ink-hover: #17305e;
  --pr-muted: #566079;
  --pr-line: #d9dde5;
  max-width: 1080px;
  margin: 0 auto;
  padding: 36px 14px 48px;
  font-family: var(--pr-font);
  font-size: 16px;
  line-height: 1.45;
  color: var(--pr-ink);
  -webkit-font-smoothing: antialiased;
}
.pr-root *, .pr-root *::before, .pr-root *::after { box-sizing: border-box; }

.pr-head { text-align: center; margin-bottom: 36px; }
.pr-eyebrow { display: block; margin-bottom: 12px; font-size: 12px; font-weight: 600; letter-spacing: 0.16em; text-transform: uppercase; color: var(--pr-muted); }
.pr-head h2 { margin: 0 0 12px; font-weight: 600; font-size: clamp(30px, 4.6vw, 44px); line-height: 1.08; letter-spacing: -0.03em; }
.pr-head p { margin: 0 auto; max-width: 520px; font-size: 16px; color: var(--pr-muted); }

/* ----- Printer ----- */
.pr-printer { position: relative; z-index: 2; width: 100%; max-width: 540px; margin: 0 auto; padding-top: 26px; }
/* paper in the input tray, peeking out behind the top of the printer */
.pr-paper { position: absolute; top: 0; left: 50%; width: 52%; height: 44px; margin-left: -26%; background: #fff; border: 1px solid #9aa0ac; border-bottom: 0; }
.pr-paper::before, .pr-paper::after { content: ""; position: absolute; left: 14px; right: 14px; height: 1px; background: #c9ced8; }
.pr-paper::before { top: 12px; }
.pr-paper::after { top: 22px; }
.pr-body {
  position: relative;
  padding: 16px 16px 28px;
  border-radius: 0;
  background: #dedbd3;
  border: 2px solid #15181e;
  box-shadow: 0 30px 40px -28px rgba(11, 27, 58, 0.55), inset 0 0 0 1px #f4f2ec;
}
.pr-top { display: flex; align-items: center; justify-content: space-between; margin: 0 0 12px; }
.pr-brand { font-size: 14px; font-weight: 600; letter-spacing: 0.22em; text-transform: uppercase; color: #15181e; }
.pr-model { display: flex; align-items: center; gap: 8px; font-size: 11px; font-weight: 500; letter-spacing: 0.16em; text-transform: uppercase; color: #5b5f6a; }
.pr-led { display: block; width: 7px; height: 7px; background: #2f9e62; }

.pr-panel { padding: 12px; background: #1b1e25; border: 1px solid #000; }
.pr-lcd { margin-bottom: 12px; padding: 10px 12px 11px; color: #8fe0a8; background: #0a110d; border: 1px solid #3a4152; border-radius: 0; box-shadow: inset 0 2px 6px rgba(0, 0, 0, 0.6); }
.pr-lcd-text { display: flex; align-items: center; gap: 10px; font-family: var(--pr-mono); font-size: 13px; letter-spacing: 0.01em; }
.pr-dot { flex: none; width: 7px; height: 7px; background: #4b5a50; }
.pr-lcd.pr-printing .pr-dot { background: #e0a03a; }
.pr-lcd.pr-served .pr-dot { background: #8fe0a8; }
.pr-bar { display: block; height: 3px; margin-top: 10px; overflow: hidden; background: rgba(143, 224, 168, 0.15); }
.pr-fill { display: block; width: 0; height: 100%; background: #8fe0a8; }
.pr-fill.pr-run { animation: pr-fill var(--pr-ms) linear forwards; }
.pr-fill.pr-done { width: 100%; }
@keyframes pr-fill { from { width: 0; } to { width: 100%; } }

.pr-keys { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; }
@media (max-width: 520px) { .pr-keys { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
.pr-key {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 52px;
  padding: 8px 12px;
  text-align: left;
  font-family: var(--pr-font);
  font-size: 14px;
  font-weight: 500;
  line-height: 1.15;
  color: #e8ebf2;
  background: #2a2f3a;
  border: 1px solid #454d5e;
  border-radius: 0;
  box-shadow: 0 2px 0 #0a0c10;
  cursor: pointer;
  transition: background 0.15s ease, border-color 0.15s ease, color 0.15s ease, transform 0.08s ease, box-shadow 0.08s ease;
}
.pr-key:hover { border-color: #7189cf; }
.pr-key:active { transform: translateY(1px); box-shadow: 0 1px 0 #0a0c10; }
.pr-key[aria-pressed="true"] { color: var(--pr-ink); background: #f1efe8; border-color: #f1efe8; box-shadow: 0 2px 0 #8d8a80; }
.pr-key[aria-disabled="true"] { cursor: progress; }
.pr-key:focus-visible, .pr-chat:focus-visible, .pr-ghostbtn:focus-visible { outline: 2px solid #7189cf; outline-offset: 3px; }
.pr-key-icon { flex: none; width: 28px; height: 28px; display: grid; place-items: center; background: var(--c); border-radius: 0; box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.18); }

/* ventilation grille */
.pr-vents { display: flex; justify-content: center; gap: 7px; margin-top: 16px; }
.pr-vents i { display: block; width: 3px; height: 14px; background: #a9a59a; }

/* output slot */
.pr-slot {
  position: absolute;
  left: 16px; right: 16px; bottom: 0;
  height: 10px;
  background: #05070a;
  box-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.9);
}

/* ----- Output ----- */
.pr-out {
  position: relative;
  z-index: 1;
  padding-bottom: 8px;
  /* hide whatever is above the slot, but let shadows show on the other sides */
  clip-path: inset(0 -90px -120px -90px);
}
.pr-empty {
  width: min(460px, calc(100% - 32px));
  aspect-ratio: 460 / 290;
  margin: 26px auto 0;
  display: grid;
  place-content: center;
  gap: 4px;
  padding: 20px;
  text-align: center;
  font-size: 15px;
  color: var(--pr-muted);
  border: 1.5px dashed var(--pr-line);
  border-radius: 0;
}
.pr-empty p { margin: 0; }
.pr-empty-title { font-size: 22px; font-weight: 600; color: var(--pr-ink); letter-spacing: -0.01em; }

.pr-row { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 460px) minmax(0, 1fr); gap: 28px; align-items: start; }
.pr-cardcol { min-width: 0; }
.pr-hint { margin: 14px 4px 0; text-align: center; font-size: 13px; color: var(--pr-muted); transition: opacity 0.3s ease; }
.pr-wait { opacity: 0; pointer-events: none; }
.pr-side { width: 190px; display: grid; gap: 10px; margin-top: 18px; transition: opacity 0.4s ease; }
.pr-side.pr-wait { visibility: hidden; }

@media (max-width: 980px) {
  .pr-row { grid-template-columns: minmax(0, 1fr); max-width: 540px; margin: 0 auto; gap: 8px; }
  .pr-spacer { display: none; }
  .pr-cardcol { width: min(460px, calc(100% - 32px)); margin: 0 auto; }
  .pr-side { width: min(460px, calc(100% - 32px)); margin: 6px auto 0; grid-template-columns: 1fr; }
}

/* the card slides out of the slot in steps, like a printer feeding it */
.pr-feed { cursor: default; transform: translateY(-12px); animation: pr-feed var(--pr-ms) linear both; }
.pr-feed.pr-fed { cursor: pointer; }
@keyframes pr-feed {
  0%   { transform: translateY(-104%); }
  18%  { transform: translateY(-80%); }
  26%  { transform: translateY(-80%); }
  46%  { transform: translateY(-52%); }
  54%  { transform: translateY(-52%); }
  74%  { transform: translateY(-24%); }
  82%  { transform: translateY(-24%); }
  100% { transform: translateY(-12px); }
}

.pr-chat, .pr-ghostbtn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  min-height: 46px;
  padding: 10px 18px;
  font-family: var(--pr-font);
  font-size: 15px;
  font-weight: 600;
  line-height: 1.1;
  text-decoration: none;
  border-radius: 0;
  cursor: pointer;
  transition: background 0.15s ease, color 0.15s ease, border-color 0.15s ease;
}
.pr-chat { color: #fff; background: var(--pr-ink); border: 1px solid var(--pr-ink); }
.pr-chat:hover { background: var(--pr-ink-hover); border-color: var(--pr-ink-hover); }
.pr-ghostbtn { color: var(--pr-ink); background: #fff; border: 1px solid #c3c9d6; }
.pr-ghostbtn:hover:not(:disabled) { background: #f3f4f7; border-color: var(--pr-ink); }
.pr-ghostbtn:disabled { opacity: 0.45; cursor: default; }
.pr-ghostbtn[aria-busy="true"] { cursor: progress; }

/* ----- Passport card (designed on a 460 x 290 grid; --u is one grid unit) ----- */
.pr-idwrap { container-type: inline-size; width: 100%; aspect-ratio: 460 / 290; perspective: 1400px; }
.pr-idinner { position: relative; width: 100%; height: 100%; transform-style: preserve-3d; transition: transform 0.7s cubic-bezier(0.3, 0.8, 0.3, 1); }
.pr-idinner.pr-flipped { transform: rotateY(180deg); }

.pr-face {
  --u: calc(100cqw / 460);
  position: absolute;
  inset: 0;
  overflow: hidden;
  border-radius: calc(var(--u) * 18);
  background: #f3f1ea;
  box-shadow: 0 calc(var(--u) * 16) calc(var(--u) * 28) calc(var(--u) * -12) rgba(11, 27, 58, 0.45), 0 0 0 1px rgba(11, 27, 58, 0.12);
  backface-visibility: hidden;
  -webkit-backface-visibility: hidden;
  color: var(--pr-ink);
}
.pr-face::before {
  content: "";
  position: absolute;
  left: 0; right: 0; top: 0;
  height: calc(var(--u) * 6);
  background: var(--c);
}
.pr-face::after {
  content: "";
  position: absolute;
  inset: calc(var(--u) * 5);
  border: 1px solid rgba(11, 27, 58, 0.12);
  border-radius: calc(var(--u) * 14);
  pointer-events: none;
}
.pr-back { transform: rotateY(180deg); }
.pr-face > * { position: absolute; display: block; line-height: 1; white-space: nowrap; }
.pr-face > ul { margin: 0; padding: 0; list-style: none; }

.pr-waves { inset: 0; width: 100%; height: 100%; fill: none; }
.pr-waves path { stroke-width: 1.1; vector-effect: non-scaling-stroke; }
.pr-waves path:nth-child(odd) { stroke: rgba(11, 27, 58, 0.075); }
.pr-waves path:nth-child(even) { stroke: rgba(11, 27, 58, 0.04); }

.pr-lab { display: block; font-size: calc(var(--u) * 9); font-weight: 500; letter-spacing: 0.11em; text-transform: uppercase; color: var(--pr-muted); }

/* front */
.pr-f-country { left: calc(var(--u) * 28); top: calc(var(--u) * 22); font-family: var(--pr-serif); font-size: calc(var(--u) * 13); font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; }
.pr-f-title { left: calc(var(--u) * 28); top: calc(var(--u) * 40); font-size: calc(var(--u) * 10); font-weight: 500; letter-spacing: 0.18em; text-transform: uppercase; color: var(--pr-muted); }
.pr-f-seal { left: calc(var(--u) * 388); top: calc(var(--u) * 18); width: calc(var(--u) * 44); height: calc(var(--u) * 44); fill: none; stroke: var(--pr-ink); stroke-width: 1.3; }
.pr-f-seal text { fill: var(--pr-ink); stroke: none; font-family: var(--pr-serif); font-size: 16px; font-weight: 600; }
.pr-f-photo {
  left: calc(var(--u) * 28); top: calc(var(--u) * 70);
  width: calc(var(--u) * 108); height: calc(var(--u) * 128);
  display: grid; place-items: center;
  border-radius: calc(var(--u) * 6);
  background: var(--c);
  box-shadow: inset 0 0 0 calc(var(--u) * 1.5) rgba(255, 255, 255, 0.35);
}
.pr-f-photo svg { width: calc(var(--u) * 64); height: calc(var(--u) * 64); }
.pr-f-ghost {
  left: calc(var(--u) * 352); top: calc(var(--u) * 88);
  width: calc(var(--u) * 80); height: calc(var(--u) * 100);
  display: grid; place-items: center;
  border-radius: calc(var(--u) * 4);
  background: var(--c);
  opacity: 0.16;
}
.pr-f-ghost svg { width: calc(var(--u) * 44); height: calc(var(--u) * 44); }
.pr-f-service { left: calc(var(--u) * 152); top: calc(var(--u) * 70); width: calc(var(--u) * 280); }
.pr-f-service b { display: block; margin-top: calc(var(--u) * 5); font-family: var(--pr-serif); font-size: calc(var(--u) * 28); font-weight: 600; letter-spacing: -0.005em; overflow: hidden; text-overflow: ellipsis; }
.pr-f-price { left: calc(var(--u) * 152); top: calc(var(--u) * 118); }
.pr-f-time { left: calc(var(--u) * 152); top: calc(var(--u) * 160); }
.pr-f-price b, .pr-f-time b { display: block; margin-top: calc(var(--u) * 5); font-size: calc(var(--u) * 20); font-weight: 600; letter-spacing: -0.01em; }
.pr-f-no { left: calc(var(--u) * 28); top: calc(var(--u) * 206); }
.pr-f-issued { left: calc(var(--u) * 168); top: calc(var(--u) * 206); }
.pr-f-no b, .pr-f-issued b { display: block; margin-top: calc(var(--u) * 5); font-size: calc(var(--u) * 14); font-weight: 600; }
.pr-f-holo {
  left: calc(var(--u) * 352); top: calc(var(--u) * 206);
  width: calc(var(--u) * 80); height: calc(var(--u) * 32);
  display: grid; place-items: center;
  border-radius: calc(var(--u) * 4);
  border: 1px solid rgba(11, 27, 58, 0.18);
  background: #d8d2c2;
  color: rgba(11, 27, 58, 0.45);
  font-family: var(--pr-serif);
  font-size: calc(var(--u) * 18);
  font-weight: 600;
}
.pr-f-tag { left: calc(var(--u) * 28); top: calc(var(--u) * 252); width: calc(var(--u) * 404); font-size: calc(var(--u) * 13); color: var(--pr-muted); overflow: hidden; text-overflow: ellipsis; }

/* back */
.pr-b-country { left: calc(var(--u) * 28); top: calc(var(--u) * 22); font-family: var(--pr-serif); font-size: calc(var(--u) * 11); font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; }
.pr-b-h { left: calc(var(--u) * 28); top: calc(var(--u) * 46); font-size: calc(var(--u) * 9); font-weight: 600; letter-spacing: 0.11em; text-transform: uppercase; color: var(--pr-muted); }
.pr-b-list { left: calc(var(--u) * 28); top: calc(var(--u) * 68); right: calc(var(--u) * 28); }
.pr-b-list li { position: relative; height: calc(var(--u) * 21); padding-left: calc(var(--u) * 22); font-size: calc(var(--u) * 14); overflow: hidden; text-overflow: ellipsis; }
.pr-b-list li::before { content: ""; position: absolute; left: calc(var(--u) * 1); top: calc(var(--u) * -2); width: calc(var(--u) * 5); height: calc(var(--u) * 10); border: solid var(--c); border-width: 0 calc(var(--u) * 2.2) calc(var(--u) * 2.2) 0; transform: rotate(45deg); }
.pr-b-tech { left: calc(var(--u) * 28); top: calc(var(--u) * 138); right: calc(var(--u) * 28); display: flex !important; gap: calc(var(--u) * 6); overflow: hidden; }
.pr-b-tech li { flex: none; height: calc(var(--u) * 22); padding: calc(var(--u) * 5) calc(var(--u) * 11) 0; font-size: calc(var(--u) * 12); font-weight: 500; background: rgba(255, 255, 255, 0.6); border: 1px solid rgba(11, 27, 58, 0.14); border-radius: calc(var(--u) * 4); }
.pr-b-note { left: calc(var(--u) * 28); top: calc(var(--u) * 176); font-size: calc(var(--u) * 11.5); color: var(--pr-muted); }
.pr-b-band { left: 0; right: 0; bottom: 0; height: calc(var(--u) * 92); background: rgba(11, 27, 58, 0.06); }
.pr-b-mrz { left: calc(var(--u) * 28); top: calc(var(--u) * 208); font-family: var(--pr-mono); font-size: calc(var(--u) * 14); line-height: calc(var(--u) * 21); }
.pr-b-bars { left: calc(var(--u) * 316); top: calc(var(--u) * 212); width: calc(var(--u) * 116); height: calc(var(--u) * 56); fill: var(--pr-ink); }

.pr-sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }

@media (prefers-reduced-motion: reduce) {
  .pr-feed { animation: none; transform: translateY(-12px); }
  .pr-fill.pr-run { animation: none; width: 100%; }
  .pr-idinner { transition: none; }
  .pr-key, .pr-chat, .pr-ghostbtn { transition: none; }
}
`;
