"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { SITE } from "../site.config";

type Props = {
  /** "" on the home page, "/" on other pages so the anchors still lead home */
  base?: string;
};

export default function SiteNav({ base = "" }: Props) {
  const [open, setOpen] = useState(false);
  const [current, setCurrent] = useState<string | null>(null);

  /* highlight the link of the section in the middle of the screen */
  useEffect(() => {
    const ids = ["top", ...SITE.nav.map((n) => n.id)];
    const els = ids.map((id) => document.getElementById(id)).filter((el): el is HTMLElement => !!el);
    if (!els.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setCurrent(e.target.id === "top" ? null : e.target.id);
        });
      },
      { rootMargin: "-45% 0px -50% 0px" },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  /* close the mobile menu with Escape */
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <header className="nav">
      <nav className="nav-inner" aria-label="Main">
        <Link className="logo" href={base || "#top"} onClick={() => setOpen(false)}>
          <span className="logo-mark" aria-hidden="true" />
          {SITE.name}
        </Link>

        <button
          type="button"
          className="nav-toggle"
          aria-expanded={open}
          aria-controls="site-menu"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((o) => !o)}
        >
          <span />
          <span />
          <span />
        </button>

        <ul id="site-menu" className={`nav-links${open ? " open" : ""}`}>
          {SITE.nav.map((n) => (
            <li key={n.id}>
              <Link
                href={`${base}${n.href}`}
                aria-current={current === n.id ? "true" : undefined}
                onClick={() => setOpen(false)}
              >
                {n.label}
              </Link>
            </li>
          ))}
          <li className="nav-cta-item">
            <Link className="btn btn-primary nav-cta" href={`${base}#contact`} onClick={() => setOpen(false)}>
              Start a project
            </Link>
          </li>
        </ul>
      </nav>
    </header>
  );
}
