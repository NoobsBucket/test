"use client";

import Link from "next/link";
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import s from "./DelovinaHero.module.css";

/* ------------------------------------------------------------------ */
/* Content                                                             */
/* ------------------------------------------------------------------ */
const SLIDES = [
  { title: "Software with depth and clarity.", lead: "Custom solutions for teams that would rather ship than wait." },
  { title: "Websites that load fast and look sharp.", lead: "Designed, built and launched end to end by one team." },
  { title: "Apps for Android, iOS and desktop.", lead: "One design language across every screen your users own." },
  { title: "Games players come back to.", lead: "Immersive worlds, smooth controls and polish in every frame." },
];

const Svg = ({ children }: { children: ReactNode }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={1.7}
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    {children}
  </svg>
);

const CHANNELS: { name: string; icon: ReactNode }[] = [
  {
    name: "Web Dev",
    icon: (
      <Svg>
        <circle cx="12" cy="12" r="9" />
        <path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18" />
      </Svg>
    ),
  },
  {
    name: "Android",
    icon: (
      <Svg>
        <path d="M6 10a6 6 0 0 1 12 0z" fill="currentColor" stroke="none" />
        <rect x="6" y="11.2" width="12" height="7.3" rx="1.6" fill="currentColor" stroke="none" />
        <rect x="3" y="11.2" width="2" height="5.8" rx="1" fill="currentColor" stroke="none" />
        <rect x="19" y="11.2" width="2" height="5.8" rx="1" fill="currentColor" stroke="none" />
        <rect x="8.6" y="17.5" width="2.2" height="3.5" rx="1.1" fill="currentColor" stroke="none" />
        <rect x="13.2" y="17.5" width="2.2" height="3.5" rx="1.1" fill="currentColor" stroke="none" />
        <path d="M8.2 4.2 7 2.4M15.8 4.2 17 2.4" />
        <circle cx="9.4" cy="7.4" r=".9" fill="#0B1A1F" stroke="none" />
        <circle cx="14.6" cy="7.4" r=".9" fill="#0B1A1F" stroke="none" />
      </Svg>
    ),
  },
  {
    name: "iOS",
    icon: (
      <Svg>
        <path
          fill="currentColor"
          stroke="none"
          d="M16.4 12.6c0-2.4 2-3.5 2.1-3.6-1.1-1.7-2.9-1.9-3.5-1.9-1.5-.15-2.9.9-3.7.9s-1.9-.85-3.1-.8c-1.6 0-3.1.95-3.9 2.4-1.7 2.9-.4 7.2 1.2 9.6.8 1.2 1.8 2.5 3 2.4 1.2 0 1.7-.8 3.1-.8s1.8.8 3.1.8c1.3 0 2.1-1.2 2.9-2.3.9-1.3 1.3-2.6 1.3-2.7 0 0-2.5-1-2.5-3.9z"
        />
        <path
          fill="currentColor"
          stroke="none"
          d="M14.2 5.2c.7-.8 1.1-1.9 1-3-1 0-2.1.7-2.8 1.5-.6.7-1.1 1.8-1 2.9 1.1.1 2.1-.6 2.8-1.4z"
        />
      </Svg>
    ),
  },
  {
    name: "Desktop",
    icon: (
      <Svg>
        <rect x="2.5" y="4" width="19" height="12" rx="1.5" />
        <path d="M8 20h8M12 16v4" />
      </Svg>
    ),
  },
  {
    name: "Games",
    icon: (
      <Svg>
        <rect x="2.5" y="7" width="19" height="11" rx="5" />
        <path d="M7.5 10.5v4M5.5 12.5h4" />
        <circle cx="16" cy="11.5" r=".8" fill="currentColor" />
        <circle cx="18" cy="13.5" r=".8" fill="currentColor" />
      </Svg>
    ),
  },
  {
    name: "Security",
    icon: (
      <Svg>
        <path d="M12 3 4.5 6v5.5c0 5 3.2 8.2 7.5 9.5 4.3-1.3 7.5-4.5 7.5-9.5V6z" />
        <path d="m8.8 12 2.4 2.4 4-4.4" />
      </Svg>
    ),
  },
  {
    name: "DevOps",
    icon: (
      <Svg>
        <path d="M12 12c-2-3-3.5-4-5.5-4a4 4 0 0 0 0 8c2 0 3.5-1 5.5-4zm0 0c2 3 3.5 4 5.5 4a4 4 0 0 0 0-8c-2 0-3.5 1-5.5 4z" />
      </Svg>
    ),
  },
];

const LAST_CHANNEL = CHANNELS.length - 1;

/* ------------------------------------------------------------------ */
/* Small SVG pieces                                                    */
/* ------------------------------------------------------------------ */
const BUG_LEGS: [number, number, number, number][] = [
  [4, 11, 0.5, 8], [16, 11, 19.5, 8],
  [3.5, 16, 0, 16], [16.5, 16, 20, 16],
  [4, 21, 0.5, 24], [16, 21, 19.5, 24],
];

function BugSvg() {
  return (
    <svg viewBox="0 0 20 28" aria-hidden="true">
      <g stroke="#1a0b0b" strokeWidth={1.3} strokeLinecap="round">
        {BUG_LEGS.map(([x1, y1, x2, y2]) => (
          <line
            key={`${x1}-${y1}`}
            className={s.l}
            x1={x1} y1={y1} x2={x2} y2={y2}
            style={{ transformOrigin: `${x1}px ${y1}px` }}
          />
        ))}
      </g>
      <ellipse cx="10" cy="17" rx="7.4" ry="9.2" fill="#E3262B" />
      <ellipse cx="7.4" cy="12.4" rx="2.2" ry="1.3" fill="#fff" opacity=".35" />
      <line x1="10" y1="8.4" x2="10" y2="26" stroke="#2a0a0c" strokeWidth={1} />
      <g fill="#1a0b0b">
        <circle cx="6.6" cy="15" r="1.4" />
        <circle cx="13.4" cy="15" r="1.4" />
        <circle cx="7" cy="20.5" r="1.2" />
        <circle cx="13" cy="20.5" r="1.2" />
      </g>
      <circle cx="10" cy="6.2" r="3.4" fill="#1a0b0b" />
      <g stroke="#1a0b0b" strokeWidth={0.9} strokeLinecap="round">
        <line x1="8.6" y1="4" x2="7" y2="1" />
        <line x1="11.4" y1="4" x2="13" y2="1" />
      </g>
    </svg>
  );
}

function BirdSvg() {
  return (
    <svg viewBox="0 0 30 22" aria-hidden="true">
      <path d="M5 12 L0 9.5 L1.2 15.5 Z" fill="#2A2F45" />
      <ellipse cx="15" cy="13" rx="9.5" ry="6.2" fill="#4A4F6A" />
      <ellipse cx="16" cy="15.4" rx="6.5" ry="3.4" fill="#E8EBF4" />
      <circle cx="23.5" cy="9.5" r="4.2" fill="#4A4F6A" />
      <path d="M27.4 9.2 L30 10.2 L27.4 11.4Z" fill="#F4A340" />
      <circle cx="24.8" cy="8.6" r=".9" fill="#fff" />
      <circle cx="25" cy="8.6" r=".45" fill="#111" />
      <path d="M12 18.5 v3.3 M17 18.5 v3.3" stroke="#F4A340" strokeWidth={1} strokeLinecap="round" />
      <g className={s.wing} style={{ transformOrigin: "14px 10px" }}>
        <path d="M14 10 C10 8, 5 9, 2.5 12.5 C7 14.5, 11 13.5, 14 12.2 Z" fill="#2A2F45" />
      </g>
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */
const cx = (...c: (string | false | null | undefined)[]) => c.filter(Boolean).join(" ");
const vars = (v: Record<string, string>) => v as CSSProperties;

const FLY_MAX = 11;
const BUG_MAX = 3;
const BIRD_MAX = 3;

type Pt = { x: number; y: number };
type Perch = { f: number; k: "top" | "cat"; busy: boolean };
type Fly = { el: HTMLSpanElement; x: number; y: number; th: number; tg: number; v: number; t: number; placed: boolean; sc: number };
type Bug = { el: HTMLDivElement; x: number; y: number; th: number; tg: number; v: number; t: number; pause: number };
type Bird = {
  el: HTMLDivElement; flip: HTMLDivElement;
  st: "away" | "in" | "perched" | "out";
  t: number; u: number; dur: number;
  p0: Pt; p1: Pt; p2: Pt;
  perch: Perch | null; face: number; bw: number; bh: number;
};

const take = <T extends HTMLElement>(arr: (T | null)[], n: number): T[] => {
  arr.forEach((el, i) => { if (el) el.style.display = i < n ? "" : "none"; });
  return arr.slice(0, n).filter((e): e is T => !!e);
};

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */
type Props = {
  /** where "Start a project" goes */
  contactHref?: string;
  /** where "Explore our work" goes */
  servicesHref?: string;
  className?: string;
};

export default function DelovinaHero({
  contactHref = "/#contact",
  servicesHref = "/#services",
  className,
}: Props) {
  /* ---------- refs ---------- */
  const sceneRef = useRef<HTMLElement>(null);
  const signRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);
  const faceRef = useRef<HTMLDivElement>(null);
  const flyRefs = useRef<(HTMLSpanElement | null)[]>([]);
  const bugRefs = useRef<(HTMLDivElement | null)[]>([]);
  const birdRefs = useRef<(HTMLDivElement | null)[]>([]);
  const flipRefs = useRef<(HTMLDivElement | null)[]>([]);

  /* ---------- rotating text ---------- */
  const [active, setActive] = useState(0);
  const [leaving, setLeaving] = useState<number | null>(null);
  const activeRef = useRef(0);
  const holdRef = useRef(false);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let leaveTimer: number | undefined;
    const id = window.setInterval(() => {
      if (holdRef.current || document.hidden) return;
      const cur = activeRef.current;
      const next = (cur + 1) % SLIDES.length;
      activeRef.current = next;
      setLeaving(cur);
      setActive(next);
      window.clearTimeout(leaveTimer);
      leaveTimer = window.setTimeout(() => setLeaving(null), 900);
    }, 4800);
    return () => {
      window.clearInterval(id);
      window.clearTimeout(leaveTimer);
    };
  }, []);

  /* ---------- retro TV ---------- */
  const [powered, setPowered] = useState(true);
  const [chIdx, setChIdx] = useState(-1);        // -1 = DELOVINA title, 0..n-1 = channels
  const [zap, setZap] = useState(false);
  const [turningOn, setTurningOn] = useState(false);
  const zapTimer = useRef<number | undefined>(undefined);
  const onTimer = useRef<number | undefined>(undefined);

  const triggerZap = useCallback(() => {
    setZap(true);
    window.clearTimeout(zapTimer.current);
    zapTimer.current = window.setTimeout(() => setZap(false), 380);
  }, []);

  // DELOVINA -> 1 -> 2 -> ... -> last -> DELOVINA -> ...
  const nextChannel = () => {
    if (!powered) return;
    setChIdx(chIdx + 1 > LAST_CHANNEL ? -1 : chIdx + 1);
    triggerZap();
  };

  const togglePower = () => {
    const next = !powered;
    setPowered(next);
    if (next) {
      setTurningOn(true);
      window.clearTimeout(onTimer.current);
      onTimer.current = window.setTimeout(() => setTurningOn(false), 600);
    }
  };

  // only the last channel ends by itself; paused while the TV is off
  useEffect(() => {
    if (!powered || chIdx !== LAST_CHANNEL) return;
    const t = window.setTimeout(() => {
      setChIdx(-1);
      triggerZap();
    }, 4500);
    return () => window.clearTimeout(t);
  }, [powered, chIdx, triggerZap]);

  useEffect(() => () => {
    window.clearTimeout(zapTimer.current);
    window.clearTimeout(onTimer.current);
  }, []);

  /* ---------- fireflies, bugs and birds (one rAF loop) ---------- */
  useEffect(() => {
    const scene = sceneRef.current;
    const sign = signRef.current;
    const frame = frameRef.current;
    const face = faceRef.current;
    if (!scene || !sign || !frame || !face) return;

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const small = window.innerWidth < 640;

    let fh = 0, bx0 = 0, bx1 = 0, by0 = 0, by1 = 0;
    let signLeft = 0, signTop = 0, sceneW = 0;

    /* fireflies */
    const flies: Fly[] = take(flyRefs.current, small ? 6 : FLY_MAX).map((el) => {
      el.style.setProperty("--dur", (2.2 + Math.random() * 2.6).toFixed(2) + "s");
      el.style.setProperty("--del", (-Math.random() * 4).toFixed(2) + "s");
      const th = Math.random() * Math.PI * 2;
      return { el, x: 0, y: 0, th, tg: th, v: 14 + Math.random() * 26, t: Math.random() * 2, placed: false, sc: 0.8 + Math.random() * 0.4 };
    });

    const placeFly = (f: Fly) => {
      f.el.style.transform = `translate3d(${f.x.toFixed(1)}px,${f.y.toFixed(1)}px,0) scale(${f.sc.toFixed(2)})`;
    };

    const stepFly = (f: Fly, dt: number) => {
      if (!f.placed) {
        f.x = bx0 + Math.random() * (bx1 - bx0);
        f.y = by0 + Math.random() * (by1 - by0);
        f.placed = true;
      }
      f.t -= dt;
      if (f.t <= 0) {
        f.tg = Math.random() * Math.PI * 2;          // any direction at all
        f.t = 0.6 + Math.random() * 2.2;
        f.v = 14 + Math.random() * 30;
      }
      if (f.x < bx0 || f.x > bx1 || f.y < by0 || f.y > by1) {
        f.tg = Math.atan2((by0 + by1) / 2 - f.y, (bx0 + bx1) / 2 - f.x) + (Math.random() - 0.5) * 1.2;
      }
      const diff = f.tg - f.th;
      f.th += Math.atan2(Math.sin(diff), Math.cos(diff)) * Math.min(1, dt * 2.2);
      f.x += Math.cos(f.th) * f.v * dt;
      f.y += Math.sin(f.th) * f.v * dt;
      placeFly(f);
    };

    /* bugs */
    const faceW = () => face.clientWidth;
    const faceH = () => face.clientHeight;

    const bugs: Bug[] = take(bugRefs.current, small ? 2 : BUG_MAX).map((el) => {
      if (!reduce) el.classList.add(s.walk);
      const th = Math.random() * Math.PI * 2;
      return {
        el,
        x: 40 + Math.random() * Math.max(10, faceW() - 80),
        y: 40 + Math.random() * Math.max(10, faceH() - 80),
        th, tg: th,
        v: 24 + Math.random() * 18,
        t: Math.random() * 2,
        pause: 0,
      };
    });

    const drawBug = (b: Bug) => {
      b.el.style.transform = `translate3d(${b.x.toFixed(1)}px,${b.y.toFixed(1)}px,0) rotate(${(b.th * 57.2958 + 90).toFixed(1)}deg)`;
    };

    /* birds */
    const perches: Perch[] = [
      { f: 0.06, k: "top" }, { f: 0.26, k: "top" }, { f: 0.5, k: "top" }, { f: 0.74, k: "top" }, { f: 0.94, k: "top" },
      { f: 0.1, k: "cat" }, { f: 0.3, k: "cat" }, { f: 0.5, k: "cat" },
    ].map((p) => ({ ...p, busy: false })) as Perch[];

    const birdEls = take(birdRefs.current, small ? 2 : BIRD_MAX);
    const birds: Bird[] = birdEls.map((el, i) => ({
      el,
      flip: flipRefs.current[i] as HTMLDivElement,
      st: "away",
      t: 1.5 + i * 3.2 + Math.random() * 2,
      u: 0, dur: 2.4,
      p0: { x: 0, y: 0 }, p1: { x: 0, y: 0 }, p2: { x: 0, y: 0 },
      perch: null, face: 1, bw: 30, bh: 22,
    }));

    const measure = () => {
      fh = frame.offsetHeight;
      signLeft = sign.offsetLeft;
      signTop = sign.offsetTop;
      sceneW = scene.clientWidth;
      bx0 = Math.max(-signLeft + 8, -70);
      bx1 = Math.min(sign.clientWidth + 70, sceneW - signLeft - 8);
      by0 = -40;
      by1 = fh + 120;
      birds.forEach((b) => { b.bw = b.el.offsetWidth || 30; b.bh = b.el.offsetHeight || 22; });
    };
    measure();

    const perchPoint = (p: Perch, b: Bird): Pt => ({
      x: p.f * sign.clientWidth,
      y: (p.k === "top" ? -3 : fh - 3) - b.bh * 0.5 + 2,
    });

    const offscreen = (side: number): Pt => ({
      x: side < 0 ? -signLeft - 80 : sceneW - signLeft + 80,
      y: -signTop * (0.15 + Math.random() * 0.75),
    });

    const quad = (a: Pt, c: Pt, b: Pt, t: number): Pt => {
      const m = 1 - t;
      return { x: m * m * a.x + 2 * m * t * c.x + t * t * b.x, y: m * m * a.y + 2 * m * t * c.y + t * t * b.y };
    };

    const setBird = (b: Bird, pos: Pt, bob = 0) => {
      b.el.style.transform = `translate3d(${(pos.x - b.bw / 2).toFixed(1)}px,${(pos.y - b.bh / 2 + bob).toFixed(1)}px,0)`;
      b.flip.style.transform = `scaleX(${b.face})`;
    };

    const startFlight = (b: Bird) => {
      const free = perches.filter((p) => !p.busy);
      if (!free.length) { b.t = 2; return; }
      const p = free[Math.floor(Math.random() * free.length)];
      p.busy = true;
      b.perch = p;
      const side = Math.random() < 0.5 ? -1 : 1;
      b.p0 = offscreen(side);
      b.p2 = perchPoint(p, b);
      b.p1 = { x: (b.p0.x + b.p2.x) / 2, y: Math.min(b.p0.y, b.p2.y) - 60 - Math.random() * 60 };
      b.face = b.p2.x >= b.p0.x ? 1 : -1;
      b.u = 0;
      b.dur = 2.2 + Math.random() * 1.2;
      b.st = "in";
      b.el.classList.add(s.on, s.flying);
      b.el.classList.remove(s.perched);
    };

    const startExit = (b: Bird) => {
      if (!b.perch) return;
      const side = Math.random() < 0.5 ? -1 : 1;
      b.p0 = perchPoint(b.perch, b);
      b.p2 = offscreen(side);
      b.p1 = { x: (b.p0.x + b.p2.x) / 2, y: Math.min(b.p0.y, b.p2.y) - 90 - Math.random() * 50 };
      b.face = b.p2.x >= b.p0.x ? 1 : -1;
      b.u = 0;
      b.dur = 2.4 + Math.random();
      b.st = "out";
      b.perch.busy = false;
      b.el.classList.add(s.flying);
      b.el.classList.remove(s.perched);
    };

    const updateBird = (b: Bird, dt: number, now: number) => {
      if (b.st === "away") {
        b.t -= dt;
        if (b.t <= 0) startFlight(b);
      } else if (b.st === "in") {
        b.u += dt / b.dur;
        if (b.u >= 1 && b.perch) {
          b.st = "perched";
          b.t = 5 + Math.random() * 7;
          b.el.classList.remove(s.flying);
          b.el.classList.add(s.perched);
          b.p2 = perchPoint(b.perch, b);
          setBird(b, b.p2, 0);
        } else {
          const e = 1 - Math.pow(1 - b.u, 3);
          setBird(b, quad(b.p0, b.p1, b.p2, e), Math.sin(now * 0.02) * 2 * (1 - b.u));
        }
      } else if (b.st === "perched" && b.perch) {
        b.t -= dt;
        if (Math.random() < dt * 0.15) { b.face = -b.face; setBird(b, perchPoint(b.perch, b), 0); }
        if (b.t <= 0) startExit(b);
      } else if (b.st === "out") {
        b.u += dt / b.dur;
        if (b.u >= 1) {
          b.st = "away";
          b.t = 3 + Math.random() * 7;
          b.el.classList.remove(s.on, s.flying);
        } else {
          setBird(b, quad(b.p0, b.p1, b.p2, b.u * b.u), Math.sin(now * 0.02) * 2);
        }
      }
    };

    /* the loop */
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;

      flies.forEach((f) => stepFly(f, dt));

      const w = faceW(), h = faceH(), m = 22;
      bugs.forEach((b) => {
        if (b.pause > 0) {
          b.pause -= dt;
          b.el.classList.remove(s.walk);
        } else {
          b.el.classList.add(s.walk);
          b.t -= dt;
          if (b.t <= 0) {
            b.tg = b.th + (Math.random() - 0.5) * 1.6;
            b.t = 1.2 + Math.random() * 2.6;
            if (Math.random() < 0.22) b.pause = 0.6 + Math.random() * 1.2;
          }
          if (b.x < m || b.x > w - m || b.y < m || b.y > h - m) {
            b.tg = Math.atan2(h / 2 - b.y, w / 2 - b.x) + (Math.random() - 0.5) * 0.6;
          }
          const diff = b.tg - b.th;
          b.th += Math.atan2(Math.sin(diff), Math.cos(diff)) * Math.min(1, dt * 3.5);
          b.x += Math.cos(b.th) * b.v * dt;
          b.y += Math.sin(b.th) * b.v * dt;
        }
        drawBug(b);
      });

      birds.forEach((b) => updateBird(b, dt, now));
      raf = requestAnimationFrame(tick);
    };

    window.addEventListener("resize", measure);
    const ro = "ResizeObserver" in window ? new ResizeObserver(measure) : null;
    ro?.observe(sign);

    if (reduce) {
      flies.forEach((f) => stepFly(f, 0));
      bugs.forEach(drawBug);
      const b = birds[0];                              // one bird sits quietly on the frame
      if (b) {
        b.perch = perches[1];
        b.perch.busy = true;
        b.st = "perched";
        b.el.classList.add(s.on, s.perched);
        setBird(b, perchPoint(b.perch, b), 0);
      }
    } else {
      raf = requestAnimationFrame(tick);
    }

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", measure);
      ro?.disconnect();
    };
  }, []);

  /* ---------- render ---------- */
  const channel = chIdx >= 0 ? CHANNELS[chIdx] : null;

  return (
    <section ref={sceneRef} className={cx(s.scene, className)}>
      {/* the billboard */}
      <div ref={signRef} className={s.sign}>
        {[1, 2, 3, 4].map((n) => (
          <div key={n} className={cx(s.lamp, s[`l${n}`])}>
            <span className={s.bulb} />
          </div>
        ))}

        <div ref={frameRef} className={s.frame}>
          <div
            ref={faceRef}
            className={s.face}
            onPointerEnter={(e) => { if (e.pointerType === "mouse") holdRef.current = true; }}
            onPointerLeave={() => { holdRef.current = false; }}
            onFocus={() => { holdRef.current = true; }}
            onBlur={() => { holdRef.current = false; }}
          >
            {[1, 2, 3, 4].map((n) => (
              <div key={n} className={cx(s.wash, s[`l${n}`])} />
            ))}

            <div className={s.brand}>Delovina</div>
            <div className={s.bars} aria-hidden="true">
              {SLIDES.map((_, i) => (
                <i key={i} className={i === active ? s.on : undefined} />
              ))}
            </div>

            <div className={s.stage}>
              {SLIDES.map((slide, i) => (
                <div
                  key={slide.title}
                  className={cx(s.slide, i === active && s.active, i === leaving && s.leaving)}
                  aria-hidden={i !== active}
                >
                  <h2 className={s.title}>{slide.title}</h2>
                  <p className={s.lead}>{slide.lead}</p>
                </div>
              ))}
            </div>

            <div className={s.actions}>
              <Link className={cx(s.btn, s.btnPrimary)} href={contactHref}>
                Start a project <span aria-hidden="true">→</span>
              </Link>
              <Link className={cx(s.btn, s.btnGhost)} href={servicesHref}>
                Explore our work
              </Link>
            </div>

            {/* walking bugs */}
            {Array.from({ length: BUG_MAX }, (_, i) => (
              <div key={i} ref={(el) => { bugRefs.current[i] = el; }} className={s.bug}>
                <BugSvg />
              </div>
            ))}
          </div>
        </div>
        <div className={s.catwalk} />

        <div className={cx(s.post, s.p1)} />
        <div className={cx(s.post, s.p2)} />

        {/* shadows on the floor */}
        <div className={s.floor} aria-hidden="true">
          <div className={s.cast} />
          <div className={s.ambient} />
          <div className={s.pshadow} style={vars({ "--l": "22%" })} />
          <div className={s.pshadow} style={vars({ "--l": "78%" })} />
          <div className={cx(s.contact, s.tvContact)} style={vars({ "--l": "50%" })} />
          <div className={s.contact} style={vars({ "--l": "22%" })} />
          <div className={s.contact} style={vars({ "--l": "78%" })} />
        </div>

        {/* retro CRT television between the legs */}
        <div
          className={cx(s.tv, !powered && s.off, turningOn && s.turningOn)}
          role="group"
          aria-label="Old television"
        >
          <div className={s.tvGlow} />
          <div className={s.tvAnt}><i /><i /></div>
          <div className={s.tvBody}>
            <div className={s.tvScreenWrap}>
              <div className={s.tvScreen}>
                <div className={cx(s.tvPic, channel && s.air, zap && s.zap)}>
                  <div className={s.tvStatic} />
                  <div className={s.home}>
                    <small>click here <i>→</i></small>
                    <b>DELOVINA</b>
                  </div>
                  {channel && (
                    <div key={chIdx} className={s.chan} aria-hidden="true">
                      <span className={s.chNo}>CH {String(chIdx + 1).padStart(2, "0")}</span>
                      <span className={s.chIc}>{channel.icon}</span>
                      <span className={s.chName}>{channel.name}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className={s.tvPanel}>
              <div className={s.tvGroup}>
                <button
                  type="button"
                  className={s.tvCh}
                  onClick={nextChannel}
                  disabled={!powered}
                  aria-label="Change channel"
                  title="Change channel"
                >
                  CH
                </button>
              </div>
              <button
                type="button"
                className={s.tvPower}
                onClick={togglePower}
                aria-pressed={powered}
                aria-label={powered ? "Turn television off" : "Turn television on"}
                title="Power"
              />
            </div>
          </div>
          <div className={s.tvFeet}><i /><i /></div>
        </div>

        {/* fireflies drift around the board */}
        <div className={s.fireflies} aria-hidden="true">
          {Array.from({ length: FLY_MAX }, (_, i) => (
            <span key={i} ref={(el) => { flyRefs.current[i] = el; }} className={s.fly} />
          ))}
        </div>

        {/* birds */}
        {Array.from({ length: BIRD_MAX }, (_, i) => (
          <div key={i} ref={(el) => { birdRefs.current[i] = el; }} className={s.bird}>
            <div ref={(el) => { flipRefs.current[i] = el; }} className={s.flip}>
              <BirdSvg />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

